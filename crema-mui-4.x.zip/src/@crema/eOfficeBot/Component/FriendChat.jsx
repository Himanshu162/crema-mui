import React, { useState } from "react";
import { Avatar } from "@material-ui/core";
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import "./FriendChat.css";

const FriendChat = ({ friend, messages, onSendMessage, onGoBack }) => {
  const [messageInput, setMessageInput] = useState("");

  const handleMessageSend = () => {
    if (messageInput.trim() !== "") {
      onSendMessage(friend.id, messageInput);
      setMessageInput("");
    }
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleMessageSend();
    }
  };

  const handleGoBack = () => {
    onGoBack();
  };

  return (
    <div className="friend-chat">
      <div className="friend-header">
        <button className="back-button" onClick={handleGoBack}>
          <KeyboardBackspaceIcon />
        </button>
        <Avatar src={friend.avatar} />
        <span className="friend-name">{friend.name}</span>
      </div>
      <div className="message-container">
        {messages.map((item, index) => (
          item.component
        ))}
      </div>
      <div className="message-input-container">
        <input
          type="text"
          value={messageInput}
          onChange={(e) => setMessageInput(e.target.value)}
          onKeyPress={handleKeyPress} // Add key press event handler
          placeholder="Type a message..."
          className="message-input"
        />
        <button onClick={handleMessageSend} className="send-button">Send</button>
      </div>
    </div>
  );
};

export default FriendChat;
